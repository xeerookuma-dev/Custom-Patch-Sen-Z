===============================================
  Custom-Patch-Sen-Z-V2 - Release v2.0
===============================================

[TH] คำอธิบายภาษาไทย
[EN] English Description

===============================================
[TH] วิธีติดตั้ง
===============================================

1. แตกไฟล์ zip ทั้งหมดไปที่ folder เกม Zenless Zone Zero
   ตัวอย่าง: E:\Program Files\.PSClients\Sen-Z_PS\CNBetaWin2.6.x\

2. ตรวจสอบว่ามีไฟล์ทั้ง 3 นี้:
   - xeekuma.dll
   - xeeroookuma.exe
   - custom

3. เปิดเกม Zenless Zone Zero

4. รัน xeeroookuma.exe (อาจต้องรันในฐานะ Administrator)

5. รอจนกว่าจะเห็นข้อความ "Injection successful"

6. กลับไปที่เกม - คุณจะเห็นข้อความกำหนดเอง!

===============================================
[TH] การแก้ไขข้อความ
===============================================

วิธีที่ 1: แก้ไขไฟล์โดยตรง
1. เปิดไฟล์ "custom" ด้วย Notepad
2. แก้ไขข้อความ
3. บันทึกไฟล์
4. เปลี่ยนภาษาในเกม (EN -> 中文 -> EN) เพื่อ refresh
5. ข้อความจะอัพเดท

วิธีที่ 2: Rebuild (สำหรับนักพัฒนา)
1. โหลด source code จาก GitHub
2. แก้ไข src/custom
3. รัน: zig build
4. คัดลอก zig-out/bin/xeekuma.dll มาแทนที่
5. รีสตาร์ทเกม

===============================================
[TH] Rich Text Tags ที่รองรับ
===============================================

<color=#ff0000>ข้อความสีแดง</color>
<color=#00ff00>ข้อความสีเขียว</color>
<b>ตัวหนา</b>
<i>ตัวเอียง</i>

ตัวอย่าง:
<color=#ff0000>นี่คือเวอร์ชั่นทดสอบ</color> <color=#00ff00>Zenless Zone Zero</color>

===============================================
[TH] แก้ปัญหา
===============================================

Q: Injector ไม่ทำงาน?
A: - ตรวจสอบว่าเกมเปิดอยู่
   - รัน injector ในฐานะ Administrator
   - ปิด antivirus ชั่วคราว

Q: ข้อความไม่แสดง?
A: - ตรวจสอบว่าไฟล์ custom อยู่ใน folder เกม
   - ลองเปลี่ยนภาษาในเกม
   - รีสตาร์ทเกมและ inject ใหม่

Q: เกม crash?
A: - ลบไฟล์ DLL และรีสตาร์ทเกม
   - ตรวจสอบว่าใช้ DLL version ที่ถูกต้อง

===============================================
[EN] Installation
===============================================

1. Extract all files to your Zenless Zone Zero game folder
   Example: E:\Program Files\.PSClients\Sen-Z_PS\CNBetaWin2.6.x\

2. Verify you have these 3 files:
   - xeekuma.dll
   - xeeroookuma.exe
   - custom

3. Open Zenless Zone Zero

4. Run xeeroookuma.exe (may need Administrator)

5. Wait for "Injection successful" message

6. Return to game - you'll see your custom message!

===============================================
[EN] Editing Messages
===============================================

Method 1: Direct File Edit
1. Open "custom" file with Notepad
2. Edit the message
3. Save the file
4. Change language in-game (EN -> 中文 -> EN) to refresh
5. Message will update

Method 2: Rebuild (for developers)
1. Download source code from GitHub
2. Edit src/custom
3. Run: zig build
4. Copy zig-out/bin/xeekuma.dll to replace old one
5. Restart game

===============================================
[EN] Supported Rich Text Tags
===============================================

<color=#ff0000>Red text</color>
<color=#00ff00>Green text</color>
<b>Bold text</b>
<i>Italic text</i>

Example:
<color=#ff0000>This is a test version</color> <color=#00ff00>Zenless Zone Zero</color>

===============================================
[EN] Troubleshooting
===============================================

Q: Injector doesn't work?
A: - Check if game is running
   - Run injector as Administrator
   - Temporarily disable antivirus

Q: Message doesn't show?
A: - Verify custom file is in game folder
   - Try changing language in-game
   - Restart game and inject again

Q: Game crashes?
A: - Remove DLL and restart game
   - Check if using correct DLL version

===============================================
⚠️ WARNING / คำเตือน
===============================================

[TH] - ใช้เพื่อการศึกษาเท่านั้น
     - อาจถูกตรวจจับโดย anti-cheat
     - ใช้ความเสี่ยงของคุณเอง
     - ไม่รับผิดชอบต่อความเสียหายใดๆ

[EN] - For educational purposes only
     - May be detected by anti-cheat
     - Use at your own risk
     - Not responsible for any damages

===============================================
📞 Support
===============================================

GitHub: https://github.com/xeeroookuma/Custom-Patch-Sen-Z-V2
Developer: xeeroookuma
Version: 2.0

===============================================
